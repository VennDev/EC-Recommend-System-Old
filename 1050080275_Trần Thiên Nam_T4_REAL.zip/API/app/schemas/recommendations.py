from pydantic import BaseModel


class RecommendationResponse(BaseModel):
    recommendations: list[dict]
